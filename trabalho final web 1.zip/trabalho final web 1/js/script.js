// Variáveis globais
let usuarioLogado = null;
let saldoMoedas = 0;

// Verificar se há um usuário logado no localStorage
function verificarUsuarioLogado() {
    const usuario = localStorage.getItem('usuarioLogado');
    const loginButton = document.getElementById('login-button');
    
    if (usuario) {
        usuarioLogado = JSON.parse(usuario);
        saldoMoedas = usuarioLogado.saldoMoedas || 0;
        
        // Atualizar a UI
        if (document.getElementById('user-coins')) {
            document.getElementById('user-coins').textContent = saldoMoedas.toLocaleString('pt-BR');
        }
        
        if (loginButton) {
            loginButton.textContent = usuarioLogado.nickname;
            loginButton.href = 'usuario.html';
        }
        
        // Mostrar links para usuários logados
        document.querySelectorAll('.btn-buy').forEach(btn => {
            btn.style.display = 'block';
        });
    } else {
        // Esconder botões de compra para usuários não logados
        document.querySelectorAll('.btn-buy').forEach(btn => {
            btn.style.display = 'none';
        });
    }
}

// JavaScript para o menu responsivo
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
        });
    }
    
    // Fechar menu ao clicar em um link
    document.querySelectorAll('.main-nav a').forEach(link => {
        link.addEventListener('click', function() {
            mainNav.classList.remove('active');
        });
    });
});

// Função para fazer logout
function fazerLogout() {
    localStorage.removeItem('usuarioLogado');
    usuarioLogado = null;
    saldoMoedas = 0;
    window.location.href = 'index.html';
}

// Inicializar a verificação do usuário
document.addEventListener('DOMContentLoaded', function() {
    verificarUsuarioLogado();
});